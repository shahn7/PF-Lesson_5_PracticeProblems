function palindromeFunction() {
	
var string = "I am awesome ";
var x = prompt("How many times to you want 'I am Awesome' to repeat?");
var repeats = parseInt(x);


function repeatString(string, repeats)
{
  return string.repeat(string, repeats);
}
document.write(string);
document.write("<br>");

}